import subprocess
import sys
import pkg_resources

# List of packages to install
packages = [
    "customtkinter",
    "vgamepad",
    "pywin32",
    "pycryptodome",
    "requests"
]

def is_package_installed(package_name):
    """Check if a package is already installed."""
    installed_packages = {pkg.key for pkg in pkg_resources.working_set}
    return package_name.lower() in installed_packages

def install(package):
    """Install the package using pip."""
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

if __name__ == "__main__":
    for package in packages:
        if not is_package_installed(package):
            print(f"Installing {package}...")
            install(package)
        else:
            print(f"{package} is already installed.")
    print("All packages have been checked and installed if necessary.")
